/*package correspondiente a la clase a testear*/
package cl.desafiolatam.moviesapp.moviedetail;

//librerias para manipular json
import com.google.gson.Gson;
//fin librerias para manipular json
//librerias para testeo
import com.google.common.truth.Truth;
import org.hamcrest.MatcherAssert;
import static org.hamcrest.Matchers.equalTo;
//mockito
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
//junit
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
//fin librerias para testeo
//clases para testear


import java.io.InputStream;
import java.io.InputStreamReader;

import cl.desafiolatam.moviesapp.data.model.MovieDetail;
import cl.desafiolatam.moviesapp.data.Repository;
import cl.desafiolatam.moviesapp.movielist.MovieListView;
//fin clases para testear

@RunWith(MockitoJUnitRunner.class)
public class MovieDetailPresenterImplTest {
    @Mock
    private MovieDetailView view;
    @Mock
    private  Repository repository;
    /*Captor captura los argumentos de los métodos simulados (mocked)
     */
    @Captor
    private ArgumentCaptor<Repository.LoadDataCallBack> detailCaptor;
    private MovieDetail movieDetail;
    private MovieDetailPresenter movieDetailPresenter;
    //campos opcionales
    private final String id = "tt0096895";
    private static final String FAILTITLE = "Barman";


    @Before
    public void setUp(){
        /* Prepara los argumentos a testear @Mock */
        MockitoAnnotations.openMocks(this);
        createData();
        movieDetailPresenter = new MovieDetailPresenterImpl(repository, view);
    }

    @After
    public void tearDown(){
        movieDetailPresenter = null;
        movieDetail = null;
    }

    @Test
    public void load (){
        //cargamos los datos llamando al método
        movieDetailPresenter.loadDataId(id);
        //utilizamos el captor para interceptar la llamada al repositorio
        Mockito.verify(repository).getMovieDetail(detailCaptor.capture(), Mockito.eq(id));
        //verificamos que se muestra el indicador de carga y se esconde el error
        Mockito.verify(view, Mockito.times(1)).showLoading();
        Mockito.verify(view, Mockito.times(1)).hideError();
        //simulamos la respuesta del repositorio exitosa
        detailCaptor.getValue().onMovieDetailResult(movieDetail);
        //verificamos que se llamen los métodos correctos en la vista
        //se para el indicador de carga, se esconde el error y se cargan los datos
        Mockito.verify(view, Mockito.times(1)).stopLoading();
        Mockito.verify(view, Mockito.times(2)).hideError();
        Mockito.verify(view, Mockito.times(1)).showMovieDetail();
    }

    @Test
    public void failLoad (){
        //cargamos los datos llamando al método
        movieDetailPresenter.loadDataId(id);
        //utilizamos el captor para interceptar la llamada al repositorio
        Mockito.verify(repository).getMovieDetail(detailCaptor.capture(), Mockito.eq(id));
        //verificamos que se muestra el indicador de carga y se esconde el error
        Mockito.verify(view, Mockito.times(1)).showLoading();
        Mockito.verify(view, Mockito.times(1)).hideError();
        //simulamos la respuesta del repositorio fallida
        detailCaptor.getValue().onDataNotAvailable();
        //verificamos que se llamen los métodos correctos en la vista
        //se para el indicador de carga, se esconde el error y se cargan los datos
        Mockito.verify(view, Mockito.times(1)).stopLoading();
        Mockito.verify(view, Mockito.times(1)).showError();
        }

    @Test
    public void loadTitle (){
        //cargamos los datos llamando al método
        movieDetailPresenter.loadDataId(id);
        //
        //utilizamos el captor para interceptar la llamada al repositorio
        Mockito.verify(repository).getMovieDetail(detailCaptor.capture(), Mockito.eq(id));
        //
        detailCaptor.getValue().onMovieDetailResult(movieDetail);
        String Title = movieDetailPresenter.getMovieTitle();
        Truth.assertThat(Title).isEqualTo("Batman");
        MatcherAssert.assertThat(Title, equalTo(Title));
    }

    @Test
    public void failLoadTitle (){
        //cargamos los datos llamando al método
        movieDetailPresenter.loadDataId(id);
        //
        //utilizamos el captor para interceptar la llamada al repositorio
        Mockito.verify(repository).getMovieDetail(detailCaptor.capture(), Mockito.eq(id));
        //
        detailCaptor.getValue().onMovieDetailResult(movieDetail);
        String Title = movieDetailPresenter.getMovieTitle();
        Truth.assertThat(movieDetailPresenter.getMovieTitle()).isEqualTo(FAILTITLE);
        MatcherAssert.assertThat(movieDetailPresenter.getMovieTitle(), equalTo(FAILTITLE));
    }



    private void createData() {
        Gson gson = new Gson();
        InputStream inputStream = ClassLoader
                .getSystemClassLoader()
                .getResourceAsStream("Batman.json");
        InputStreamReader reader = new InputStreamReader(inputStream);
        movieDetail = gson.fromJson(reader, MovieDetail.class);
    }



}
