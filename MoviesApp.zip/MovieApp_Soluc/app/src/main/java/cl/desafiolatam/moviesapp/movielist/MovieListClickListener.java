package cl.desafiolatam.moviesapp.movielist;

import cl.desafiolatam.moviesapp.data.model.MovieResult;

public interface MovieListClickListener {
    void onItemClick(MovieResult movieResult);
}
