package com.example.intentsparte2;

public class ResultActivity {
}
