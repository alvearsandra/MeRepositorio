package com.example.passwordstrong;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private EditText editText;
  //  private View root;
    private TextView textColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    //    root = findViewById(R.id.root);
        textColor = findViewById(R.id.textView);
        textView = findViewById(R.id.textView);
        editText = findViewById(R.id.editText);
        //actualizar strong password en tiempo real con textwatcher
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                    calculatePasswordStrength(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

    }
    //calcular fortaleza pass
    private void calculatePasswordStrength(String str){
        PasswordStrength passwordStrength = PasswordStrength.calculate(str) ;
        textView.setText(passwordStrength.msg);
     //   root.setBackgroundColor(passwordStrength.color);
        textColor.setBackgroundColor(passwordStrength.color);

    }
}