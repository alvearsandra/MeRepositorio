package cl.desafiolatam.transformerapp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Calendar;
import java.util.TimeZone;

//configuración inicial
@RunWith(MockitoJUnitRunner.class)
public class TransformerPresenterImplTest {
    @Mock
    private TransformerView view;
    private TransformerPresenter presenter;
    private final Calendar calendarDate = Calendar.getInstance(TimeZone.getTimeZone("UTC"));

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        presenter = new TransformerPresenterImpl();
        presenter.setView(view);
        //esta fecha puede ser definida, pero es la fecha inicial
        calendarDate.set(2021,1,21);
    }

    @After
    public void tearDown() {
        presenter.removeView();
    }
    //fin de la configuración inicial


    @Test
    public void setDate() {
        //importante agregar la fecha, si no el test falla, ya que la fecha es null
        presenter.setDate(calendarDate.getTime().getTime());
        //lo único que usamos de mockito en este test para verificar.
        Mockito.verify(view, Mockito.times(1)).showDateResult();
        Assert.assertEquals("Thursday, March 28, 2019", presenter.getStringDate());
    }

    @Test
    public void getStringDate() {
        //prueba de null para la fecha
        Assert.assertNull(presenter.getStringDate());
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals("Thursday, March 28, 2019", presenter.getStringDate());
    }


    @Test
    public void getDaysOnly() {
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals("Día del mes: 28", presenter.getDaysOnly());
        calendarDate.set(2020, 3, 20);
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals("Día del mes: 20", presenter.getDaysOnly());
    }


    @Test
    public void getWeeksOnly() {
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals("Semana del año: 13", presenter.getWeeksOnly());
        calendarDate.set(2020, 3, 20);
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals("Semana del año: 17", presenter.getWeeksOnly());
    }


    @Test
    public void getTimeStamp() {
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals(calendarDate.getTimeInMillis(), presenter.getTimeStamp().longValue());
        calendarDate.set(2021, 1, 21);
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals(calendarDate.getTimeInMillis(), presenter.getTimeStamp().longValue());
    }


    @Test
    public void getDateFormatOne() {
        presenter.setDate(calendarDate.getTimeInMillis());
        Assert.assertEquals("21/02/2023", presenter.getDateFormatOne());
        calendarDate.set(2021, 1, 21);
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals("21/02/2021", presenter.getDateFormatOne());
    }


    @Test
    public void getDateFormatTwo() {
        presenter.setDate(calendarDate.getTimeInMillis());
        Assert.assertEquals("28 - 03 - 2019", presenter.getDateFormatTwo());
        calendarDate.set(2020, 3, 20);
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals("20 - 04 - 2020", presenter.getDateFormatTwo());
    }


    @Test
    public void getDateFormatThree() {
        presenter.setDate(calendarDate.getTimeInMillis());
        Assert.assertEquals("Thu, Mar 28, 2019", presenter.getDateFormatThree());
        calendarDate.set(2020, 3, 20);
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals("Mon, Apr 20, 2020", presenter.getDateFormatThree());
    }


    @Test
    public void getDateFormatFour() {
        presenter.setDate(calendarDate.getTimeInMillis());
        Assert.assertEquals("Thursday 28", presenter.getDateFormatFour());
        calendarDate.set(2020, 3, 20);
        presenter.setDate(calendarDate.getTime().getTime());
        Assert.assertEquals("Monday 20", presenter.getDateFormatFour());
    }



}