package com.example.preguntadinamica.API;


import com.example.preguntadinamica.pojo.Pregunta;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api {

    //https://opentdb.com/api.php?amount=1&category=18&difficulty=medium&type=boolean

    @GET("api.php?amount=10&category=15&difficulty=easy")
    Call<Pregunta> getAllQuestion();

}
