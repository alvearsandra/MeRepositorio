package com.example.preguntadinamica;


import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.preguntadinamica.API.Api;
import com.example.preguntadinamica.API.RetrofitClient;
import com.example.preguntadinamica.pojo.Pregunta;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

   // private static final String TAG = "API_log";

    TextView pregunta;
    TextView categoria;
    TextView dificultad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pregunta = findViewById(R.id.pregunta);
        categoria = findViewById(R.id.categoria);
        dificultad = findViewById(R.id.dificultad);
       // Log.i(TAG,"onCreate: Creando la  actividad");


        Api service = RetrofitClient.getRetrofitInstance().create(Api.class);
        Call<Pregunta> call = service.getAllQuestion();

        call.enqueue(new Callback<Pregunta>()
        {

            @Override
            public void onResponse(Call<Pregunta> call, Response<Pregunta> response)
            {
                Pregunta preguntas = response.body();

            }

            @Override
            public void onFailure(Call<Pregunta> call, Throwable t)
            {
                Toast.makeText(getApplicationContext(), "Error: no se puede recuperar los datos de la API, insista más tarde",  Toast.LENGTH_SHORT).show();
            }

        });
    
    }

}