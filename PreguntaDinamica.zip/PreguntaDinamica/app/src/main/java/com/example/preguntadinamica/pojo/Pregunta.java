package com.example.preguntadinamica.pojo;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.SerializedName;

public class Pregunta
{

    @SerializedName("question")
    private  String question;

    @SerializedName("category")
    private String category;

     @SerializedName("difficulty")
    private String difficulty;


    /*  GETTERS  AND  SETTERS*/
    public String getQuestion() {
        return question;
    }
    public void setQuestion(String question) {
        this.question = question;
    }

    public String getCategory(){
        return category;
    }
    public void setCategory(String category){
        this.category = category;
    }

    public String getDifficulty() {
        return difficulty;
    }
    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }



}
