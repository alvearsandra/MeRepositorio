package com.example.preguntadinamica;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.Objects;


public class BlankFragment extends  Fragment {

    private TextView pregunta, categoria, dificultad;

    public BlankFragment(){}


    public static BlankFragment newInstance(String preguntadin, String categoria, String dificultad) {
        BlankFragment fragment = new BlankFragment();
        Bundle args = new Bundle();
        args.putString("PREGUNTA", preguntadin);
        args.putString("CATEGORIA", categoria);
        args.putString("DIFICULTAD", dificultad);
        fragment.setArguments(args);
        return fragment;
    }

      @Override
      public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState)
      {
        super.onCreateView(inflater,container,savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_blank, container,false);
        if(view != null) {
            textView = (pregunta) view.findViewById(R.id.pregunta),
            textView = (textView) view.findViewById(R.id.categoria),
            textView = (textView) view.findViewById(R.id.dificultad);

           // final String preguntadin = Objects.requireNonNull(getArguments()).getString("PREGUNTA");
          //  final String categoria = Objects.requireNonNull(getArguments()).getString("CATEGORIA");
          //  final String dificultd = Objects.requireNonNull(getArguments()).getString("DIFICULTAD");
        }
        //INICIALIZAR VISTAS  DECLARADAS
          initializeViews(view);

          preguntaView.setText(preguntadin);
          categoriaView.setText(categoria);
          dificultadView.setText(dificultd);
        return inflater.inflate(R.layout.fragment_blank, container, false);
    }


    private void initializeViews(View view) {
        preguntaView = view.findViewById(R.id.pregunta);
        categoriaView = view.findViewById(R.id.categoria);
        dificultadView = view.findViewById(R.id.dificultad);
    }
}