package com.example.recyclerviewparte1;

public class PostresFitness {
    private static DesertFit[] dessertFits = {  new DesertFit(0, "Brownies bananas", R.drawable.brownie),
                                                new DesertFit (1,"Galletas", R.drawable.galletas),
                                                new DesertFit(2, "Muffins", R.drawable.muffins),
                                                new DesertFit(3,"Palmeritas", R.drawable.palmeritas),
                                                new DesertFit(4,"Pan de Calabaza", R.drawable.pancalabaza),
                                                new DesertFit(5,"Panquecas", R.drawable.panquecas)
    };





    }












}
