package com.example.recyclerviewparte1;

public class DetailActivity {
}
