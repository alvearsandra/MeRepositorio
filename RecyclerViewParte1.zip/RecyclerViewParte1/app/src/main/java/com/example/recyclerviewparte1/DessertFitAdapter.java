package com.example.recyclerviewparte1;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DessertFitAdapter extends RecyclerView.Adapter<DessertFitAdapter.ViewHolder> {
    private LayoutInflater mLayoutInflater;
    private List<DessertFitAdapter> mDessertFit = new ArrayList<>();
    private Context mContext;
    private OnItemClickListener listener;

    public interface OnItemClickListener{
        public void onClick(DessertFitAdapter.ViewHolder viewHolder, int idDessertFit);

    }

    public DessertFitAdapter(Context context, List<DesertFit> dessertFits, OnItemClickListener listener){
        mContext = context;
        mLayoutInflater = mLayoutInflater.from(context);
        mDessertFit = dessertFits;
        this.listener = listener;
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView mNombre;
        private ImageView mImagen;
        public ViewHolder(View dessertfitView) {
            super(dessertfitView);
            mNombre = (TextView) dessertfitView.findViewById(R.id.list_item_textView);
            mImagen = (ImageView) dessertfitView.findViewById(R.id.avatar);
            dessertfitView.setOnClickListener(this);
            mNombre.setOnClickListener(this);
            mImagen.setOnClickListener(this);
        }

        

        }
    }
}
