package com.example.recyclerviewparte1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;

import com.google.android.material.appbar.CollapsingToolbarLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements MainActivity.DessertFitAdapter.onItemClickListener {
    private RecyclerView mRecyclerView;
    private DessertFitAdapter mAdapter;
    private CollapsingToolbarLayout mCollapsingToolbarLayout;




    //enlazar recycler en la activity y con su respectiva vista en el XML en metodo oncreate


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mRecyclerView = (RecyclerView) findViewById(R.id.recycler);
        //pasamos 3 parametros: se envia el contexto donde se esta implementando
        // el segundo parametro: listado de elementos
        // tercer parametro: pasarmos el listener implementado en actividad.
        mAdapter = new DessertFitAdapter(this,PostresFitness.getPostresFitness(),this);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
     // al hacer click nos lleva a una nueva  vista
    @Override
    public void onClick(DessertFitAdapter.ViewHolder viewHolder, int idDessertFit){
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra(DetailActivity.ID_DESSERTFIT, idDessertFit);
        startActivity(intent);
    }

    public abstract class DessertFitAdapter extends RecyclerView.Adapter<DessertFitAdapter.ViewHolder>{
        private LayoutInflater mLayoutInflater;
        private List<DesertFit> mDessertFit = new ArrayList();
        private Context mContext;
        private onItemClickListener listener;

        public class ViewHolder extends RecyclerView.ViewHolder {
        }
    }




}