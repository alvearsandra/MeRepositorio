package DesafioUno

import java.lang.Byte.MAX_VALUE
import java.lang.Integer.MIN_VALUE
import kotlin.math.max

fun main(){

    /*1.- crear proyecto
    * 2.- crear archivo Main.kt
    * 3.- imprimir mi nombre es
    * */
/*
    val minombre:String
    minombre ="Sandra Alvear V."
    println("Mi nombre es  $minombre")

    //4.- Declarar 3 variables numericas
    val numuno =10
    val numdos = 20
    val numtres = 30
    var suma = numuno+numdos+numtres

    // 5.-  Imprimir la suma de las tres variables
    println("Suma total tres variables $numuno+$numdos+$numtres   es:  $suma")

    // 6.- Declarar una variable de tipo Float de forma explícita
     var variable: Char = 'P'
      var variablecadena: String = "variable string"

    // 7.- Asignarle el valor "Arataka Reigen" a la variable String y "A" a la variable Char
      var variableString = "Arataka Reigen"
      var variableChar = 'A'

    /*8.- Imprimir la cantidad de caracteres que tiene la variable String y modificar la
     variable char a otro valor distinto*/
    println("total caracteres  :  ${variableString.count()}")
    println("valor de Char ${variable}")

    /*9.- Declarar variable de tipo Float de forma explícita*/
    var declararflotante:Float

    //10.- Asignar un valor a la varibale Float
    var variablefloat:Float =585.88f

    //11.- Imprimir los valores máximos que pueden almacenar las variables Byte y Short


         println("Valor Maximo de variable  Byte es   $MAX_VALUE.Byte")
         println("Valor Máximo de variable  Short es  $MAX_VALUE.Short")

    //12.- Imprimir  los valores mínimos que pueden almacenar las variables int y Long

          println("Valor mínimo  de  variable Int  es $MIN_VALUE.Int")
           println("Valor mínimo  de  variable  Long es  $MIN_VALUE.Long")


        //13.-  Declarar una variable Boolean con true o false e imprimir su valor
          var variabletrue : Boolean = true
           println("Variable verdadera de veritas $variabletrue")

*/



    /*14.- Crear una función llamada imprimiendoParametros que recibe 2 parametros String
         y este imprime el total de caracteres de los dos parámetros  */

        fun imprimiendoParametros(var1: String , var2: String )
        {
               println("$var1: ${var1.count()}")
               println("$var2: ${var2.count()}")
        }
          // (imprimiendoParametros("desdeaquillamoavar1, noesnecesarioelprint", "aquiestallamandoavar2noesnecesarioprint"))


    /* 15.- Crear una función llamada obtieneIVA  que devuelve el valor del IVA(19%)*/

                fun obtenerIVA(){
                  //  var  bueniva = (19f)
                  //  val factor = 100
                 //  var resul: Float = bueniva/factor
                    var resul:Float = 19/100f


                   println("Valor del IVA en Chilito = $resul")
                }

              //    obtenerIVA()



    /* 16.- Desde la función  main llamar a estas dos funciones de forma  correcta  */

    (imprimiendoParametros("desdeaquillamoavar1, noesnecesarioelprint", "aquiestallamandoavar2noesnecesarioprint"))
    obtenerIVA()
}


