package com.example.homepageapp;

import android.content.BroadcastReceiver;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

public class Home extends AppCompatActivity {
    private BroadcastReceiver broadcastReceiver;
    static TextView mostrarimagen;
}
