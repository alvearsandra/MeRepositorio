
data class LibrosEscolares(
    var nombreLibro: String,
    var isbn: String,
    var anioPublicacion : Int,
    var editorial: String,
    var cantPaginas : String,
    var  precio: Float,
    var autorLibro : String,
    var tipoLibro : Char)
{
    fun imprimirLibros(){
        println("Nombre del Libro: $nombreLibro")
        println("ISBN: $isbn")
        println("Año publicación : $anioPublicacion")
        println("Editorial: $editorial})")
        println("Cantidad de páginas: $cantPaginas")
        println("Precio : ${precioFormateado()}")
        println("Autor libro: $autorLibro")
        println("Tipo libro D:Digital    I:Impreso: $tipoLibro")
    }



}


