fun LibrosEscolares.precioFormateado() : String{
    return "$ ${this.precio}"
}