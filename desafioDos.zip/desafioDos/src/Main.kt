fun main() {
    val libro1Inmutable = LibrosEscolares(
        "El Cantar Mio Cid",
        "102-254-K5455-32000",
        1200,
        "Diego Marín",
        "VM",
        25600.45f,
        "Anonimo",
        'I'
    )

    val libro2Mutable = LibrosEscolares(
        "El principito",
        "5625-555kk0",
        1974,
        "Planeta",
        "80",
        5590.55f,
        "Saint-Exupery",
        'I'
    )

    val libro3Mutable = LibrosEscolares(
        "Tercer Libro",
        "110.3652-8544-444",
        2010,
        "Planeta",
        "100",
        10255.55f,
        "Autor 3",
        'I'

    )

    val libro4Mutable = LibrosEscolares(
        "Cuarto  Libro",
        "854-555-W44",
        2021,
        "Planeta",
        "100",
        1875.55f,
        "Autor 4",
        'D'

    )

    println("Primer libro Inmutable")
    println("--------------------------")
    libro1Inmutable.imprimirLibros()
    println("")
    println("Primer libro Mutable")
    libro2Mutable.imprimirLibros()
    println("")
    println("--------------------------")
    println("Segundo libro Mutable")
    libro3Mutable.imprimirLibros()
    println("")
    println("--------------------------")
    println("Tercero libro Mutable")
    libro4Mutable.imprimirLibros()



}