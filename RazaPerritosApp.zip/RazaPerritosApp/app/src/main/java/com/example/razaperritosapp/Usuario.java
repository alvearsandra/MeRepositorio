package com.example.razaperritosapp;

import java.io.Serializable;

public class Usuario implements Serializable {
    private String name;
    private String lastName;
    private String address;


    public Usuario(String name, String lastName, String address){
        this.name = name;
        this.lastName = lastName;
        this.address = address;
    }

    public String getName(){
        return name;
    }

    public String getLastName(){
        return lastName;
    }

    public String getAddress(){
        return address;
    }

    public void setName(String name){
        this.name = name;
    }

    public void setLastName(String lastName){
        this.lastName = lastName;
    }

    public void setAddress(String address){
        this.address = address;
    }
}

